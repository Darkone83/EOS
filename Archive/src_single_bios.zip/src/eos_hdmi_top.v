// eos_hdmi_top.v -- Eos LPC BIOS server, SDRAM-backed.
//
// DIRECT-LCLK TEST BUILD:
// - LPC loader and backend loader-side now run directly from lpc_lclk.
// - This removes the ~371 MHz HDMI serial clock from the LPC critical path.
// - D0 is assumed physically grounded for testing.
// - LFRAME# is still monitored for diagnostics but does not block basic START decode.

module eos_hdmi_top (
    input              sys_clk,
    input              rst_btn,

    input              lpc_lclk,
    input              lpc_lframe_n,
    input              lpc_lreset_n,
    inout      [3:0]   lpc_lad,

    output     [5:0]   led,

    output             tmds_clk_p,
    output             tmds_clk_n,
    output      [2:0]  tmds_d_p,
    output      [2:0]  tmds_d_n,

    output             flash_cs_n,
    output             flash_clk,
    output             flash_mosi,
    input              flash_miso,

    output             ws2812,

    // ---- on-chip SDRAM: magic names, leave OUT of the .cst ----
    output             O_sdram_clk,
    output             O_sdram_cke,
    output             O_sdram_cs_n,
    output             O_sdram_cas_n,
    output             O_sdram_ras_n,
    output             O_sdram_wen_n,
    inout      [31:0]  IO_sdram_dq,
    output     [10:0]  O_sdram_addr,
    output     [1:0]   O_sdram_ba,
    output     [3:0]   O_sdram_dqm
);

    // -------------------------------------------------------------------------
    // HDMI clocks
    // -------------------------------------------------------------------------

    wire serial_clk;
    wire pix_clk;
    wire hpll_lock;

    Gowin_rPLL u_hpll (
        .clkin  (sys_clk),
        .clkout (serial_clk),
        .lock   (hpll_lock)
    );

    reg [7:0] por = 8'd0;

    always @(posedge sys_clk) begin
        if (!hpll_lock)
            por <= 8'd0;
        else if (~&por)
            por <= por + 1'b1;
    end

    wire hdmi_rst_n = &por;

    CLKDIV u_clkdiv (
        .RESETN (hdmi_rst_n),
        .HCLKIN (serial_clk),
        .CLKOUT (pix_clk),
        .CALIB  (1'b1)
    );

    defparam u_clkdiv.DIV_MODE = "5";
    defparam u_clkdiv.GSREN    = "false";

    // -------------------------------------------------------------------------
    // SDRAM clocks
    // -------------------------------------------------------------------------

    wire clk_sd;
    wire clk_sdp;
    wire spll_lock;

    eos_sdram_pll u_spll (
        .clkin   (sys_clk),
        .clkout  (clk_sd),
        .clkoutp (clk_sdp),
        .lock    (spll_lock)
    );

    reg [9:0] spor = 10'd0;

    always @(posedge clk_sd) begin
        if (!spll_lock)
            spor <= 10'd0;
        else if (~&spor)
            spor <= spor + 1'b1;
    end

    wire sd_rstn = &spor;

    // -------------------------------------------------------------------------
    // LPC clock
    // -------------------------------------------------------------------------
    //
    // DIRECT-LCLK TEST:
    // Use Xbox LPC clock directly for loader-side logic.
    // This avoids the 371 MHz serial_clk timing risk.
    //
    // Backend already CDCs from lclk-domain to sclk-domain internally.

    wire clk_lpc = lpc_lclk;

    // -------------------------------------------------------------------------
    // LPC loader
    // -------------------------------------------------------------------------

    wire        mem_req;
    wire        mem_valid;
    wire [17:0] mem_addr;
    wire [7:0]  mem_data;

    wire [3:0]  lst;
    wire        lad_oe_c;
    wire [3:0]  lad_out_c;

    eos_lpc_loader u_loader (
        .clk          (clk_lpc),
        .lreset_n     (lpc_lreset_n),

        .lclk_pin     (lpc_lclk),
        .lframe_n_pin (lpc_lframe_n),
        .lad_pin      (lpc_lad),

        .lad_out      (lad_out_c),
        .lad_oe       (lad_oe_c),

        .mem_req      (mem_req),
        .mem_addr     (mem_addr),
        .mem_valid    (mem_valid),
        .mem_data     (mem_data),

        .state        (lst)
    );

    assign lpc_lad = lad_oe_c ? lad_out_c : 4'bzzzz;

    // -------------------------------------------------------------------------
    // SDRAM-backed BIOS server
    // -------------------------------------------------------------------------

    wire        sd_rd;
    wire        sd_wr;
    wire        sd_refresh;
    wire [22:0] sd_addr;
    wire [7:0]  sd_din;
    wire [7:0]  sd_dout;
    wire        sd_dr;
    wire        sd_busy;
    wire        preload_done;
    wire [22:0] dbg_filled_lo;

    eos_sdram_backend u_be (
        .lclk          (clk_lpc),
        .lresetn       (lpc_lreset_n),

        .mem_req       (mem_req),
        .mem_addr      (mem_addr),
        .mem_valid     (mem_valid),
        .mem_data      (mem_data),

        .sclk          (clk_sd),
        .sresetn       (sd_rstn),

        .sd_rd         (sd_rd),
        .sd_wr         (sd_wr),
        .sd_refresh    (sd_refresh),
        .sd_addr       (sd_addr),
        .sd_din        (sd_din),
        .sd_dout       (sd_dout),
        .sd_data_ready (sd_dr),
        .sd_busy       (sd_busy),

        .flash_cs_n    (flash_cs_n),
        .flash_clk     (flash_clk),
        .flash_mosi    (flash_mosi),
        .flash_miso    (flash_miso),

        .preload_done  (preload_done),
        .dbg_filled_lo (dbg_filled_lo)
    );

    sdram #(
        .FREQ(64_800_000)
    ) u_sdram (
        .clk        (clk_sd),
        .clk_sdram  (clk_sdp),
        .resetn     (sd_rstn),

        .addr       (sd_addr),
        .rd         (sd_rd),
        .wr         (sd_wr),
        .refresh    (sd_refresh),

        .din        (sd_din),
        .dout       (sd_dout),
        .dout32     (),
        .data_ready (sd_dr),
        .busy       (sd_busy),

        .SDRAM_DQ   (IO_sdram_dq),
        .SDRAM_A    (O_sdram_addr),
        .SDRAM_BA   (O_sdram_ba),
        .SDRAM_nCS  (O_sdram_cs_n),
        .SDRAM_nWE  (O_sdram_wen_n),
        .SDRAM_nRAS (O_sdram_ras_n),
        .SDRAM_nCAS (O_sdram_cas_n),
        .SDRAM_CLK  (O_sdram_clk),
        .SDRAM_CKE  (O_sdram_cke),
        .SDRAM_DQM  (O_sdram_dqm)
    );

    // -------------------------------------------------------------------------
    // HDMI HUD
    // -------------------------------------------------------------------------

    wire        wr_en;
    wire [12:0] wr_addr;
    wire [7:0]  wr_data;
    wire [2:0]  wr_attr;

    eos_serve_hud u_hud (
        .lclk         (clk_lpc),
        .lreset_n     (lpc_lreset_n),
        .vclk         (pix_clk),

        .state        (lst),
        .mem_addr     (mem_addr),
        .lad          (lpc_lad),

        .mem_valid    (mem_valid),
        .sd_ready     (sd_rstn),
        .preload_done (preload_done),
        .filled_lo    (dbg_filled_lo),

        .wr_en        (wr_en),
        .wr_addr      (wr_addr),
        .wr_data      (wr_data),
        .wr_attr      (wr_attr)
    );

    wire       vs_t;
    wire       hs_t;
    wire       de_t;
    wire [7:0] ur;
    wire [7:0] ug;
    wire [7:0] ub;

    testpattern u_pat (
        .I_pxl_clk  (pix_clk),
        .I_rst_n    (hdmi_rst_n),
        .I_mode     (3'd0),

        .I_single_r (8'd0),
        .I_single_g (8'd255),
        .I_single_b (8'd0),

        .I_h_total  (12'd1650),
        .I_h_sync   (12'd40),
        .I_h_bporch (12'd220),
        .I_h_res    (12'd1280),

        .I_v_total  (12'd750),
        .I_v_sync   (12'd5),
        .I_v_bporch (12'd20),
        .I_v_res    (12'd720),

        .I_hs_pol   (1'b1),
        .I_vs_pol   (1'b1),

        .O_de       (de_t),
        .O_hs       (hs_t),
        .O_vs       (vs_t),
        .O_data_r   (ur),
        .O_data_g   (ug),
        .O_data_b   (ub)
    );

    wire       vs_o;
    wire       hs_o;
    wire       de_o;
    wire [7:0] r;
    wire [7:0] g;
    wire [7:0] b;

    eos_text_render u_render (
        .pclk    (pix_clk),
        .rst_n   (hdmi_rst_n),

        .de_in   (de_t),
        .hs_in   (hs_t),
        .vs_in   (vs_t),

        .wr_clk  (pix_clk),
        .wr_en   (wr_en),
        .wr_addr (wr_addr),
        .wr_data (wr_data),
        .wr_attr (wr_attr),

        .de_o    (de_o),
        .hs_o    (hs_o),
        .vs_o    (vs_o),
        .r_o     (r),
        .g_o     (g),
        .b_o     (b)
    );

    DVI_TX_Top u_dvi (
        .I_rst_n       (hdmi_rst_n),
        .I_serial_clk  (serial_clk),
        .I_rgb_clk     (pix_clk),

        .I_rgb_vs      (vs_o),
        .I_rgb_hs      (hs_o),
        .I_rgb_de      (de_o),
        .I_rgb_r       (r),
        .I_rgb_g       (g),
        .I_rgb_b       (b),

        .O_tmds_clk_p  (tmds_clk_p),
        .O_tmds_clk_n  (tmds_clk_n),
        .O_tmds_data_p (tmds_d_p),
        .O_tmds_data_n (tmds_d_n)
    );

      // -------------------------------------------------------------------------
    // Status LEDs + WS2812 boot-status mode
    // -------------------------------------------------------------------------
    //
    // Post-breakthrough meaning:
    //
    // WS2812:
    //   Red pulse      = LPC reset not released
    //   Yellow pulse   = no LPC clock seen
    //   Amber          = BIOS preload not complete
    //   Blue heartbeat = BIOS resident / ready / idle
    //   Green blink    = LPC BIOS read served
    //   Cyan heartbeat = sustained boot/read activity
    //
    // Tang Nano 20K onboard LEDs are active-low:
    //   led[5] = preload done
    //   led[4] = LPC reset high seen
    //   led[3] = LCLK edge seen
    //   led[2] = LAD START seen
    //   led[1] = loader drove LAD
    //   led[0] = byte served

    function [23:0] RGB_TO_GRB;
        input [7:0] rr;
        input [7:0] gg;
        input [7:0] bb;
        begin
            RGB_TO_GRB = {gg, rr, bb};
        end
    endfunction

    // -------------------------------------------------------------------------
    // preload_done into sys_clk domain
    // -------------------------------------------------------------------------

    reg [2:0] pd_s = 3'b000;

    always @(posedge sys_clk) begin
        pd_s <= {pd_s[1:0], preload_done};
    end

    wire pdone = pd_s[2];

    // -------------------------------------------------------------------------
    // Raw LPC visibility in sys_clk domain
    // -------------------------------------------------------------------------

    reg [2:0] lreset_s = 3'b000;
    reg [2:0] lclk_s   = 3'b000;

    reg [3:0] lad_a_sys = 4'hF;
    reg [3:0] lad_b_sys = 4'hF;

    always @(posedge sys_clk) begin
        lreset_s <= {lreset_s[1:0], lpc_lreset_n};
        lclk_s   <= {lclk_s[1:0],   lpc_lclk};

        lad_a_sys <= lpc_lad;
        lad_b_sys <= lad_a_sys;
    end

    wire raw_reset_high = lreset_s[2];
    wire raw_lclk_edge  = lclk_s[2] ^ lclk_s[1];
    wire raw_lad_zero   = (lad_b_sys == 4'h0);

    reg seen_reset_high = 1'b0;
    reg seen_lclk_edge  = 1'b0;
    reg seen_lad_zero   = 1'b0;

    always @(posedge sys_clk) begin
        if (raw_reset_high)
            seen_reset_high <= 1'b1;

        if (raw_lclk_edge)
            seen_lclk_edge <= 1'b1;

        if (raw_lad_zero)
            seen_lad_zero <= 1'b1;
    end

    // -------------------------------------------------------------------------
    // Loader-domain sticky/activity flags
    // -------------------------------------------------------------------------

    reg b_start  = 1'b0;
    reg b_drive  = 1'b0;
    reg b_sync   = 1'b0;
    reg b_serv   = 1'b0;
    reg serv_tog = 1'b0;

    always @(posedge clk_lpc or negedge lpc_lreset_n) begin
        if (!lpc_lreset_n) begin
            b_start  <= 1'b0;
            b_drive  <= 1'b0;
            b_sync   <= 1'b0;
            b_serv   <= 1'b0;
            serv_tog <= 1'b0;
        end else begin
            if (lst != 4'd0)
                b_start <= 1'b1;

            if (lad_oe_c)
                b_drive <= 1'b1;

            if (lst == 4'd6)
                b_sync <= 1'b1;

            if (mem_valid) begin
                b_serv   <= 1'b1;
                serv_tog <= ~serv_tog;
            end
        end
    end

    assign led = ~{
        pdone,
        seen_reset_high,
        seen_lclk_edge,
        seen_lad_zero,
        b_drive,
        b_serv
    };

    // -------------------------------------------------------------------------
    // WS2812 cold-start delay
    // -------------------------------------------------------------------------

    reg [18:0] ws_por = 19'd0;

    always @(posedge sys_clk) begin
        if (ws_por != 19'd270000)
            ws_por <= ws_por + 1'b1;
    end

    wire ws_rst_n = (ws_por == 19'd270000);

    // -------------------------------------------------------------------------
    // Heartbeat
    // -------------------------------------------------------------------------

    reg [24:0] hb = 25'd0;

    always @(posedge sys_clk) begin
        hb <= hb + 1'b1;
    end

    // -------------------------------------------------------------------------
    // Serve activity pulse and sustained boot activity window
    // -------------------------------------------------------------------------

    reg [2:0] tog_s = 3'b000;

    always @(posedge sys_clk) begin
        tog_s <= {tog_s[1:0], serv_tog};
    end

    wire serve_evt = tog_s[2] ^ tog_s[1];

    // Short green blink on each visible serve burst.
    reg [20:0] serve_pulse = 21'd0;

    always @(posedge sys_clk) begin
        if (serve_evt)
            serve_pulse <= 21'd540000;       // ~20 ms at 27 MHz
        else if (serve_pulse != 0)
            serve_pulse <= serve_pulse - 1'b1;
    end

    // Longer activity window. If reads keep happening, this stays nonzero.
    // This lets a successful boot/activity phase show cyan instead of falling
    // back to red/idle between green pulses.
    reg [24:0] boot_activity = 25'd0;

    always @(posedge sys_clk) begin
        if (serve_evt)
            boot_activity <= 25'd13500000;   // ~500 ms at 27 MHz
        else if (boot_activity != 0)
            boot_activity <= boot_activity - 1'b1;
    end

    // Optional crude serve counter. Useful if you later want to expose this to HUD.
    reg [15:0] serve_count = 16'd0;

    always @(posedge sys_clk) begin
        if (serve_evt)
            serve_count <= serve_count + 1'b1;
    end

    // -------------------------------------------------------------------------
    // WS2812 boot-status color logic
    // -------------------------------------------------------------------------

    reg [23:0] color;

    always @(posedge sys_clk) begin
        if (!seen_reset_high) begin
            // Xbox LPC reset not released / not seen.
            color <= hb[23] ? RGB_TO_GRB(8'h30, 8'h00, 8'h00)
                            : RGB_TO_GRB(8'h04, 8'h00, 8'h00);   // red pulse
        end else if (!seen_lclk_edge) begin
            // LPC reset is high, but no LPC clock detected.
            color <= hb[23] ? RGB_TO_GRB(8'h30, 8'h20, 8'h00)
                            : RGB_TO_GRB(8'h04, 8'h03, 8'h00);   // yellow/orange pulse
        end else if (!pdone) begin
            // BIOS still preloading from flash to SDRAM.
            color <= RGB_TO_GRB(8'h30, 8'h18, 8'h00);             // amber
        end else if (serve_pulse != 0) begin
            // Active LPC byte serve.
            color <= RGB_TO_GRB(8'h00, 8'h40, 8'h00);             // green blink
        end else if (boot_activity != 0) begin
            // Sustained boot activity / healthy ongoing reads.
            color <= hb[24] ? RGB_TO_GRB(8'h00, 8'h20, 8'h20)
                            : RGB_TO_GRB(8'h00, 8'h06, 8'h06);   // cyan heartbeat
        end else if (!seen_lad_zero) begin
            // Ready and clocked, but no START observed yet.
            color <= hb[24] ? RGB_TO_GRB(8'h00, 8'h00, 8'h20)
                            : RGB_TO_GRB(8'h00, 8'h00, 8'h04);   // blue heartbeat
        end else if (b_drive || b_serv) begin
            // Known-good idle after successful bus activity.
            // This used to be dim red; make it blue so success doesn't look like fault.
            color <= hb[24] ? RGB_TO_GRB(8'h00, 8'h00, 8'h20)
                            : RGB_TO_GRB(8'h00, 8'h00, 8'h04);   // blue heartbeat
        end else begin
            // Resident and waiting.
            color <= hb[24] ? RGB_TO_GRB(8'h00, 8'h00, 8'h18)
                            : RGB_TO_GRB(8'h00, 8'h00, 8'h03);   // dim blue
        end
    end

    eos_ws2812 #(
        .CLK_HZ(27_000_000)
    ) u_ws (
        .clk    (sys_clk),
        .rstn   (ws_rst_n),
        .grb    (color),
        .ws_out (ws2812)
    );

endmodule