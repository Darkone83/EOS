`define USE_TLVDS_OBUF
