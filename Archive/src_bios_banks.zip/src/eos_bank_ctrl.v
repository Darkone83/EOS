// eos_bank_ctrl.v -- Eos bank mapping / management / flashing controller.
// =====================================================================
// POC SKELETON. Models Eos as a Xenium-like memory partition whose logical
// origin is PHYSICAL flash 0x200000 (the byte just past the 2MB FPGA bitstream
// region). Provides:
//   1) the 0xEF bank register (OpenXenium write/read semantics)
//   2) logical -> physical translation:  phys = FLOOR + bank_base + offset
//   3) a HARD write/erase floor at FLOOR (bitstream brick-guard)
//   4) a SPI flash program/erase engine (WREN / sector-erase / page-program /
//      status-poll) -- the "flashing" path, floor-guarded.
//
// SAFETY INVARIANT (non-negotiable): no erase or program may target a physical
// address < FLOOR. The bitstream lives at 0x000000..FLOOR-1 and is, by design,
// UNADDRESSABLE through the logical map; the floor check below is the redundant
// backstop for any raw physical write path.
//
// INTEGRATION NOTE: the current eos_lpc_loader exposes only mem_addr[17:0] and
// no IO/write routing. For this controller the loader must be widened to expose:
//   - io_wr_stb + io_addr[15:0] + io_data[7:0]      (to catch I/O writes to 0xEF)
//   - mem cycle + mem_addr[20:0] + mem_wr_stb + mem_wr_data[7:0]  (2MB + writes)
// Those are inputs here; wiring them is a loader change tracked separately.
// =====================================================================
module eos_bank_ctrl #(
    parameter [23:0] FLOOR     = 24'h200000,   // physical origin of the logical map
    parameter [15:0] IO_PORT   = 16'h00EF,     // Xenium control register
    parameter integer ALEN     = 21            // logical address bits (2MB = 21)
)(
    input  wire        clk,            // sys clock for the flash engine
    input  wire        cold_rstn,      // COLD power-on reset (clears bank -> menu)
    input  wire        warm_reset,     // warm reset pulse (bank PERSISTS across this)

    // ---- LPC I/O side: write to 0xEF latches bank/SPI bits ----
    input  wire        io_wr_stb,      // 1-cycle strobe: an LPC I/O write occurred
    input  wire [15:0] io_addr,        // I/O address of that write
    input  wire [7:0]  io_data,        // data byte written
    input  wire        io_rd_stb,      // LPC I/O read to 0xEF (for read-back)
    input  wire [15:0] io_rd_addr,
    output reg  [7:0]  io_rd_data,     // value returned on 0xEF read

    // ---- LPC MEM side: translate logical -> physical for the read path ----
    input  wire [ALEN-1:0] mem_logical, // logical address from the bus
    output wire [23:0]     mem_phys,    // translated physical flash address

    // ---- flashing command interface (from menu XBE via MEM_WRITE decode, or
    //      from the on-chip programmer; abstracted here as a simple request) ----
    input  wire        fl_req,         // pulse: start a flash op
    input  wire [1:0]  fl_op,          // 0=page program, 1=sector erase, 2=chip-area erase(NA), 3=reserved
    input  wire [23:0] fl_phys_addr,   // ALREADY-translated physical target
    input  wire [7:0]  fl_wr_data,     // byte for page-program (POC: 1 byte; real: buffer)
    output reg         fl_busy,
    output reg         fl_done,
    output reg         fl_refused,     // asserted if op was below FLOOR (guard tripped)

    // ---- SPI flash pins (shared bus; arbitration with reader handled in top) ----
    output reg         flash_cs_n,
    output reg         flash_clk,
    output reg         flash_mosi,
    input  wire        flash_miso
);
    // ----------------------------------------------------------------
    // 1) 0xEF BANK REGISTER  (OpenXenium semantics)
    //    write: {X, SCK, CS, MOSI, BANK[3:0]}   read: {RECOV,X,MISO,MISO,BANK[3:0]}
    //    Bank persists across warm reset; cold POR returns to bank 0 (menu).
    // ----------------------------------------------------------------
    reg [3:0] bank_sel;
    localparam [3:0] BANK_MENU = 4'd0;     // Eos: bank 0 = menu (cold default)

    wire ef_hit_wr = io_wr_stb && (io_addr == IO_PORT);
    wire ef_hit_rd = io_rd_stb && (io_rd_addr == IO_PORT);

    always @(posedge clk or negedge cold_rstn) begin
        if (!cold_rstn) begin
            bank_sel <= BANK_MENU;          // COLD only -> menu
        end else begin
            // NOTE: warm_reset deliberately does NOT clear bank_sel, so a
            // menu-pick-then-warm-reset lands on the chosen bank.
            if (ef_hit_wr) bank_sel <= io_data[3:0];
        end
    end

    // 0xEF read-back (recovery switch tied inactive here; MISO bits as 0 for POC)
    always @(*) begin
        io_rd_data = ef_hit_rd ? {1'b1 /*RECOV inactive*/, 1'b0, 1'b0, 1'b0, bank_sel}
                               : 8'h00;
    end

    // ----------------------------------------------------------------
    // 2) LOGICAL -> PHYSICAL TRANSLATION
    //    bank_base() is the logical offset of the active bank. Default map below
    //    mirrors OpenXenium so the borrowed kernel finds its XBE exactly as on a
    //    real Xenium; the Eos 1MB-stride extension banks are the commented rows.
    //    phys = FLOOR + bank_base(bank_sel) + (logical masked to bank size)
    // ----------------------------------------------------------------
    function [20:0] bank_base; input [3:0] b; begin
        case (b)
            // ---- OpenXenium-faithful (POC: reproduce so kernel finds XBE) ----
            4'b0010: bank_base = 21'h100000; // XeniumOS / menu bank (512K)
            4'b0011: bank_base = 21'h000000; // user 256K #1
            4'b0100: bank_base = 21'h040000; // user 256K #2
            4'b0101: bank_base = 21'h080000; // user 256K #3
            4'b0110: bank_base = 21'h0C0000; // user 256K #4
            4'b0111: bank_base = 21'h000000; // user 512K #1
            4'b1000: bank_base = 21'h080000; // user 512K #2
            4'b1001: bank_base = 21'h000000; // user 1MB
            4'b1010: bank_base = 21'h1C0000; // recovery (Xenium tail)
            // ---- Eos extension banks would live ABOVE the 2MB Xenium space,
            //      i.e. at physical 0x400000+, reached by widening this map and
            //      the phys adder below to >21 logical bits. Left as TODO so the
            //      POC stays Xenium-exact. ----
            default: bank_base = 21'h000000; // bank 0 / menu base
        endcase
    end endfunction

    // active bank base + masked logical offset, lifted into physical by FLOOR
    wire [20:0] base = bank_base(bank_sel);
    assign mem_phys = FLOOR + {3'b000, base} + {3'b000, mem_logical};

    // ----------------------------------------------------------------
    // 3) WRITE/ERASE FLOOR GUARD  (brick-prevention backstop)
    //    Any flash program/erase whose physical target is below FLOOR is refused.
    // ----------------------------------------------------------------
    wire fl_below_floor = (fl_phys_addr < FLOOR);

    // ----------------------------------------------------------------
    // 4) SPI FLASH PROGRAM / ERASE ENGINE  (the "flashing" path)
    //    Standard SPI: 0x06 WREN, 0x20 sector-erase, 0x02 page-program,
    //    0x05 read-status (poll WIP bit0). POC: single-byte program; real build
    //    streams a page buffer. Shift MSB-first; very small bit-banged master.
    // ----------------------------------------------------------------
    localparam OP_PP = 2'd0, OP_SE = 2'd1;
    localparam F_IDLE=0, F_WREN=1, F_CMD=2, F_POLL=3, F_DONE=4, F_REFUSE=5;
    reg [2:0]  fst;
    reg [39:0] sh;        // up to cmd(8)+addr(24)+data(8) = 40 bits
    reg [5:0]  nbits;
    reg [1:0]  op_l;
    reg [23:0] addr_l;
    reg [7:0]  data_l;
    reg        sck;       // simple half-rate toggle
    reg [7:0]  stat;      // status read shift

    // (POC) one SCK per two clks; real build uses a divider like the reader.
    always @(posedge clk or negedge cold_rstn) begin
        if (!cold_rstn) begin
            fst<=F_IDLE; fl_busy<=0; fl_done<=0; fl_refused<=0;
            flash_cs_n<=1; flash_clk<=0; flash_mosi<=0; sck<=0;
        end else begin
            fl_done<=0;
            case (fst)
                F_IDLE: begin
                    flash_cs_n<=1; flash_clk<=0; fl_busy<=0;
                    if (fl_req) begin
                        if (fl_below_floor) begin
                            fl_refused<=1; fst<=F_REFUSE;   // GUARD: never touch <FLOOR
                        end else begin
                            fl_refused<=0; fl_busy<=1;
                            op_l<=fl_op; addr_l<=fl_phys_addr; data_l<=fl_wr_data;
                            // issue WREN (0x06) first
                            sh<={8'h06,32'h0}; nbits<=6'd8; flash_cs_n<=0; sck<=0; fst<=F_WREN;
                        end
                    end
                end
                F_WREN: begin
                    // shift 8 bits of WREN, then CS high, then the op command
                    sck<=~sck; flash_clk<=sck;
                    if (sck) begin                       // falling edge: advance
                        flash_mosi<=sh[39];
                        sh<={sh[38:0],1'b0}; nbits<=nbits-1'b1;
                        if (nbits==1) begin
                            flash_cs_n<=1;               // deassert to commit WREN
                            // build the op frame
                            if (op_l==OP_SE) begin sh<={8'h20,addr_l,8'h00}; nbits<=6'd32; end
                            else             begin sh<={8'h02,addr_l,data_l};  nbits<=6'd40; end
                            fst<=F_CMD; flash_cs_n<=0;
                        end
                    end
                end
                F_CMD: begin
                    sck<=~sck; flash_clk<=sck;
                    if (sck) begin
                        flash_mosi<=sh[39];
                        sh<={sh[38:0],1'b0}; nbits<=nbits-1'b1;
                        if (nbits==1) begin flash_cs_n<=1; fst<=F_POLL; sck<=0; end
                    end
                end
                F_POLL: begin
                    // TODO: real status polling (0x05, sample WIP bit until clear).
                    // POC: jump to DONE; bench build must poll before signalling done.
                    fst<=F_DONE;
                end
                F_DONE:   begin fl_busy<=0; fl_done<=1; fst<=F_IDLE; end
                F_REFUSE: begin fl_busy<=0; fl_done<=1; fst<=F_IDLE; end // done w/ refused=1
            endcase
        end
    end
endmodule